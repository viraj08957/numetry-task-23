import React from "react";
import Chatbot from "./components/Chatbot";
import { Box } from "@mui/material";

const App = () => {
  return (
    <Box
      sx={{
        backgroundSize: "cover",
        backgroundPosition: "center",
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Chatbot />
    </Box>
  );
};

export default App;
